# Anime Assistant (Android, Kotlin + Jetpack Compose)

A personal voice assistant app with a gentle, anime-styled persona named "Yui."
She listens to your voice, replies in a soft female TTS voice, and can run a
few real device commands directly.

## What she can actually do

- **Talk to you** — any open-ended question/chat goes to the Claude API and
  comes back in a short, warm, gentle-voiced reply (`ClaudeApiClient.kt`).
- **Set alarms** — "set alarm for 7 30 am" opens your phone's Clock app with
  the alarm pre-filled (`CommandHandler.kt`, uses `AlarmClock.ACTION_SET_ALARM`,
  no special permission needed).
- **Web search** — "search for ramen recipes" launches a search.
- **Open apps** — "open spotify" launches any installed app by name.
- **Speak gently** — TTS pitch/rate are tuned softer in `MainActivity.onInit()`,
  and it tries to auto-select a female system voice if one is available.

## What she can't do (and why)

Android sandboxes every app for good reason. This project deliberately does
**not** include:
- Reading other apps' private data, messages, notifications, or files
- Background always-listening / spying
- Anything requiring root or Accessibility Service abuse to control other apps

Those capabilities are what malware uses, regardless of intent, so they're out
of scope here. Everything included uses normal, user-visible Android APIs.

## Setup

1. Open this folder in **Android Studio** (Hedgehog or newer).
2. Get an Anthropic API key from console.anthropic.com.
3. In `MainActivity.kt`, replace:
   ```kotlin
   private val claudeApiKey = "YOUR_ANTHROPIC_API_KEY_HERE"
   ```
   **Better:** put it in `local.properties` as `ANTHROPIC_API_KEY=sk-ant-...`,
   expose it via `BuildConfig` in `build.gradle.kts`, and read
   `BuildConfig.ANTHROPIC_API_KEY` instead — so the key never sits in source
   control or a shipped APK in plain text.
4. Build → Run on a device or emulator (minSdk 26 / Android 8.0+).
5. Grant the microphone permission when prompted (you'll need to add a
   runtime permission request for `RECORD_AUDIO` — Android 6+ requires asking
   at runtime, not just in the manifest; see `ActivityCompat.requestPermissions`).

## Avatar

The current avatar is a simple colored circle that changes expression while
thinking/speaking — a placeholder. To get a real anime character:
- Easiest: swap the `Box` in `AssistantScreen` for an `Image()` using a sprite
  sheet (idle / talking / happy frames) you commission or generate, switched
  based on `isSpeaking`/`isThinking`.
- Fuller: integrate a Live2D Cubism SDK for Android for a fully animated,
  lip-synced character — that's a separate, sizeable integration.

## Next steps worth doing

- Runtime mic permission request (currently relies on the manifest only)
- Loading/error states polish
- Persist conversation history
- Replace placeholder avatar with real art/animation
