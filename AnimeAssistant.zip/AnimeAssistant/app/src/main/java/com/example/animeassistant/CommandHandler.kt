package com.example.animeassistant

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import java.util.Calendar
import java.util.regex.Pattern

/**
 * Looks at what the user said and decides whether it's a device command
 * (alarm / search / open app) or something to forward to Claude for a
 * conversational reply.
 */
class CommandHandler(private val activity: Activity) {

    sealed class Result {
        data class Spoken(val reply: String) : Result()
        data class NeedsChat(val text: String) : Result()
    }

    fun handle(text: String): Result {
        val lower = text.lowercase().trim()

        // --- Set an alarm: "set alarm for 7 30", "wake me up at 6:45 am" ---
        if (lower.contains("alarm") || lower.contains("wake me")) {
            val time = extractTime(lower)
            if (time != null) {
                setAlarm(time.first, time.second)
                return Result.Spoken("Okay, I've set an alarm for ${formatTime(time.first, time.second)}.")
            }
            return Result.Spoken("I heard 'alarm', but I couldn't catch the time. Try saying it like 'set alarm for 7 30 am'.")
        }

        // --- Web search: "search for ramen recipes", "google best phones 2026" ---
        if (lower.startsWith("search for") || lower.startsWith("search") || lower.startsWith("google")) {
            val query = lower
                .removePrefix("search for")
                .removePrefix("search")
                .removePrefix("google")
                .trim()
            if (query.isNotBlank()) {
                webSearch(query)
                return Result.Spoken("Here's what I found for \"$query\".")
            }
        }

        // --- Open an app: "open spotify", "launch camera" ---
        if (lower.startsWith("open ") || lower.startsWith("launch ")) {
            val appName = lower.removePrefix("open ").removePrefix("launch ").trim()
            val opened = openApp(appName)
            return if (opened) {
                Result.Spoken("Opening $appName for you.")
            } else {
                Result.Spoken("I couldn't find an app called $appName on your phone.")
            }
        }

        // --- Everything else goes to Claude for a normal conversational reply ---
        return Result.NeedsChat(text)
    }

    // Parses things like "7 30", "7:30", "7", "7 am", "19:45"
    private fun extractTime(text: String): Pair<Int, Int>? {
        val pattern = Pattern.compile("(\\d{1,2})[:\\s]?(\\d{2})?\\s*(am|pm)?")
        val matcher = pattern.matcher(text)
        if (matcher.find()) {
            var hour = matcher.group(1)?.toIntOrNull() ?: return null
            val minute = matcher.group(2)?.toIntOrNull() ?: 0
            val ampm = matcher.group(3)
            if (ampm == "pm" && hour < 12) hour += 12
            if (ampm == "am" && hour == 12) hour = 0
            if (hour in 0..23 && minute in 0..59) return Pair(hour, minute)
        }
        return null
    }

    private fun formatTime(hour: Int, minute: Int): String {
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val suffix = if (hour < 12) "AM" else "PM"
        return String.format("%d:%02d %s", h12, minute, suffix)
    }

    private fun setAlarm(hour: Int, minute: Int) {
        val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
            putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
            putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
        }
        try {
            activity.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // No clock app available; silently ignore, caller already gave a spoken reply.
        }
    }

    private fun webSearch(query: String) {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
        }
        try {
            activity.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun openApp(appName: String): Boolean {
        val pm = activity.packageManager
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(appName)
        } ?: return false

        val launchIntent = pm.getLaunchIntentForPackage(match.packageName) ?: return false
        activity.startActivity(launchIntent)
        return true
    }
}
