package com.example.animeassistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Thin wrapper around the Anthropic Messages API.
 *
 * IMPORTANT: Put your own Anthropic API key in local.properties as
 *   ANTHROPIC_API_KEY=sk-ant-xxxx
 * and wire it through BuildConfig (see README) rather than hardcoding it here.
 * Never ship a real API key inside a public APK — anyone can extract it.
 */
class ClaudeApiClient(private val apiKey: String) {

    private val client = OkHttpClient()
    private val endpoint = "https://api.anthropic.com/v1/messages"

    private val personaSystemPrompt = """
        You are Yui, a gentle, warm, soft-spoken anime girl AI assistant living on the
        user's phone. Keep replies short (1-3 sentences), kind, a little playful, and
        easy to speak aloud naturally with text-to-speech. Avoid asterisked actions or
        emojis. Speak directly to the user.
    """.trimIndent()

    fun sendMessage(userText: String, onResult: (String) -> Unit, onError: (String) -> Unit) {
        val body = JSONObject().apply {
            put("model", "claude-sonnet-4-6")
            put("max_tokens", 300)
            put("system", personaSystemPrompt)
            put("messages", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("content", userText)
                }
            ))
        }

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                onError("I couldn't reach the network just now: ${e.message}")
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.use {
                    if (!it.isSuccessful) {
                        onError("Something went wrong talking to my brain (code ${it.code}).")
                        return
                    }
                    val json = JSONObject(it.body?.string().orEmpty())
                    val content = json.optJSONArray("content")
                    val text = StringBuilder()
                    if (content != null) {
                        for (i in 0 until content.length()) {
                            val block = content.getJSONObject(i)
                            if (block.optString("type") == "text") {
                                text.append(block.optString("text"))
                            }
                        }
                    }
                    onResult(text.toString().ifBlank { "I'm not sure what to say to that." })
                }
            }
        })
    }
}
