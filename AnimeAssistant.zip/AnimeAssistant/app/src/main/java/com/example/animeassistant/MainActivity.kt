package com.example.animeassistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var commandHandler: CommandHandler

    // TODO: move this to a secure source (local.properties / BuildConfig), never hardcode for release.
    private val claudeApiKey = "YOUR_ANTHROPIC_API_KEY_HERE"
    private val claude by lazy { ClaudeApiClient(claudeApiKey) }

    private var lastReply by mutableStateOf("Hi, I'm Yui. Tap the mic and tell me what to do~")
    private var isSpeaking by mutableStateOf(false)
    private var isThinking by mutableStateOf(false)

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) {
                handleUserInput(text)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        commandHandler = CommandHandler(this)

        setContent {
            MaterialTheme {
                AssistantScreen(
                    reply = lastReply,
                    isSpeaking = isSpeaking,
                    isThinking = isThinking,
                    onMicTap = { startListening() }
                )
            }
        }
    }

    // Configure a gentle-sounding female voice once TTS engine is ready.
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setPitch(1.15f)   // slightly higher pitch reads as softer/gentler
            tts.setSpeechRate(0.92f) // slightly slower, calmer pacing

            val femaleVoice = tts.voices?.firstOrNull {
                it.name.contains("female", ignoreCase = true) ||
                it.name.contains("#female", ignoreCase = true)
            }
            femaleVoice?.let { tts.voice = it }
        }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell me what to do~")
        }
        speechLauncher.launch(intent)
    }

    private fun handleUserInput(text: String) {
        when (val result = commandHandler.handle(text)) {
            is CommandHandler.Result.Spoken -> speak(result.reply)
            is CommandHandler.Result.NeedsChat -> {
                isThinking = true
                claude.sendMessage(
                    userText = result.text,
                    onResult = { reply -> runOnUiThread { isThinking = false; speak(reply) } },
                    onError = { error -> runOnUiThread { isThinking = false; speak(error) } }
                )
            }
        }
    }

    private fun speak(text: String) {
        lastReply = text
        isSpeaking = true
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utteranceId")
        // crude reset of the speaking flag; for production hook UtteranceProgressListener instead
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { isSpeaking = false }
            override fun onError(utteranceId: String?) { isSpeaking = false }
        })
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}

@Composable
fun AssistantScreen(
    reply: String,
    isSpeaking: Boolean,
    isThinking: Boolean,
    onMicTap: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF0F5)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            // Placeholder avatar circle — swap with a real anime sprite/Live2D view later.
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .background(
                        color = if (isSpeaking) Color(0xFFFFB6C1) else Color(0xFFFFC0CB),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isThinking) "..." else if (isSpeaking) "♪" else "^_^",
                    fontSize = 48.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Text(
                    text = reply,
                    modifier = Modifier.padding(16.dp),
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onMicTap,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8FAB)),
                modifier = Modifier.size(72.dp),
                shape = CircleShape
            ) {
                Text("🎤", fontSize = 24.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("Tap to speak", color = Color.Gray, fontSize = 13.sp)
        }
    }
}
